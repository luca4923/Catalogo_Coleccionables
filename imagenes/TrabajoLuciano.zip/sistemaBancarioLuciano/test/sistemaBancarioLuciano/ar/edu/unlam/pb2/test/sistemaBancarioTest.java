package sistemaBancarioLuciano.ar.edu.unlam.pb2.test;

import static org.junit.Assert.*;
import java.util.List;
import org.junit.Before;
import org.junit.Test;

import sistemaBancarioLuciano.ar.edu.unlam.pb2.Banco;
import sistemaBancarioLuciano.ar.edu.unlam.pb2.CajaAhorro;
import sistemaBancarioLuciano.ar.edu.unlam.pb2.Cuenta;
import sistemaBancarioLuciano.ar.edu.unlam.pb2.CuentaCorriente;

public class sistemaBancarioTest {
	private Banco banco;

	@Before
	public void setUp() {
		banco = new Banco("Banco Escuela");
		banco.agregarCuenta(new CajaAhorro(1, "Ana", 1000.0));
		banco.agregarCuenta(new CuentaCorriente(2, "Luis", 500.0, 1000.0));
	}

	// Depositar 50 devuelve true y el saldo pasa de 100 a 150 en la CajaAhorro.
	@Test
	public void depositarCajaAhorroDebeAumentarElSaldo() {
		banco.agregarCuenta(new CajaAhorro(3, "vieja", 100.0));
		banco.depositar(3, 50.0);
		assertEquals(banco.buscarCuenta(3).getSaldo(), 150.0, 0.0);

	}

	// Extraer 50 de la CajaAhorro devuelve true. Se descuentan 50 + 5 de comisión:
	// el saldo final es 45.
	@Test
	public void extraerCajaAhorroDebeDescontarMontoMasComision() {
		banco.agregarCuenta(new CajaAhorro(3, "vieja", 100.0));
		banco.extraer(3, 50.0);
		assertEquals(banco.buscarCuenta(3).getSaldo(), 45.0, 0.0);

	}

	// Extraer 1200 de la CuentaCorriente con id = 2 devuelve true y el saldo queda
	// en -700 (usa el descubierto).
	@Test
	public void extraerCuentaCorrienteUsandoElDescubiertoDebeDejarSaldoNegativo() {
		banco.extraer(2, 1200.0);
		assertEquals(banco.buscarCuenta(2).getSaldo(), -700, 0.0);

	}

	// Se declaran dos variables de tipo Transferible (CajaAhorro y CuentaCorriente,
	// saldo 500). Se llama extraer(100) sobre cada una. La caja queda en 395
	// (comisión) y la corriente en 400.
	@Test
	public void extraerSobreTransferibleDebeAplicarLaReglaDeCadaTipoDeCuenta() {

		banco.agregarCuenta(new CajaAhorro(3, "vieja", 500.0));
		banco.extraer(3, 100.0);
		assertEquals(banco.buscarCuenta(3).getSaldo(), 395, 0.0);
		banco.agregarCuenta(new CuentaCorriente(4, "vieja", 500.0, 1000.0));
		banco.extraer(4, 100.0);
		assertEquals(banco.buscarCuenta(4).getSaldo(), 400, 0.0);
	}

	// Se guardan una CajaAhorro y una CuentaCorriente en un misma coleccion de
	// Cuenta. Se deposita 100 en cada una y se verifica que ambas subieron 100
	@Test
	public void depositarEnColeccionDeCuentasDebeTratarATodasPorIgual() {
		banco.agregarCuenta(new CajaAhorro(3, "vieja", 500.0));
		banco.agregarCuenta(new CuentaCorriente(4, "vieja", 500.0, 1000.0));
		banco.depositar(3, 100.0);
		banco.depositar(4, 100.0);
		assertEquals(banco.buscarCuenta(3).getSaldo(), 600.0, 0.0);
		assertEquals(banco.buscarCuenta(4).getSaldo(), 600.0, 0.0);

	}

	// Agregar una CajaAhorro con id nuevo devuelve true y cantidadDeCuentas
	// aumenta.
	@Test
	public void agregarCajaAhorroNuevaDebeDevolverTrueYAumentarLaCantidad() {
		banco.agregarCuenta(new CajaAhorro(4, "fdf", 500.0));
		assertEquals(banco.getCuentas(), 3, 0.0);
	}

	// No debería permitir agregar una cuenta con id existente
	@Test
	public void noPermitirAgregarCajaDeAhorroConIdDuplicado() {
		banco.agregarCuenta(new CajaAhorro(4, "fdf", 500.0));
		assertFalse(banco.agregarCuenta(new CajaAhorro(4, "fdf", 500.0)));
	}
	
	// Buscar una Cuenta Corriente con id 9 retorna null 
	@Test 
	public void buscarCuentaInexistenteDebeRetornarNull() { 
	assertNull(banco.buscarCuenta(9)); 
	} 
	
	// Tras depositar en la CajaAhorro hay 1 movimiento: idCuenta 1, tipo DEPOSITO, 
	// monto pedido.
	@Test 
	public void depositarEnCajaAhorroDebeRegistrarUnMovimientoDeDeposito() { 
		banco.agregarCuenta(new CajaAhorro(4, "fdf", 500.0));
		banco.depositar(4, 100.0);
		assertEquals(banco.getMovimientos(), 1, 0.0);
	} 
	
	// Tras transferir entre CajaAhorro y CuentaCorriente hay 2 movimientos, en 
	// orden: TRANSFERENCIA_ENVIADA y TRANSFERENCIA_RECIBIDA. 
	
	@Test 
	public void transferirEntreCajaAhorroYCuentaCorrienteDebeRegistrarMovimientoEnviadoYRecibido() { 
		banco.agregarCuenta(new CajaAhorro(4, "fdf", 500.0));
		banco.agregarCuenta(new CuentaCorriente(5, "vieja", 500.0, 1000.0));
		banco.transferir(4, 5, 100.0);
		assertEquals(banco.getMovimientos(), 2, 0.0);
//		assertEquals(banco.buscarCuenta(5).getSaldo(), 600.0, 0.0);
		
		
	} 
	
	// transferir con destino inexistente devuelve false. El saldo de la CajaAhorro 
	// origen no debe descontarse y no hay movimientos. 
	@Test 
	public void transferirConDestinoInexistenteNoDebeDescontarDeCajaAhorroOrigen() { 
		banco.agregarCuenta(new CajaAhorro(4, "fdf", 500.0));
		banco.agregarCuenta(new CuentaCorriente(5, "vieja", 500.0, 1000.0));
		banco.transferir(4, 6, 100.0);
		assertEquals(banco.getMovimientos(), 0, 0.0);
		assertEquals(banco.buscarCuenta(4).getSaldo(), 500.0 , 0.0);
	
	}
	// Se hace depositar, extraer y transferir. Se verifica que getMovimientos() los 
	// devuelve en el orden cronológico en que ocurrieron. 
	@Test 
	public void depositarExtraerYTransferirDebeMantenerElOrdenCronologicoDeMovimientos() { 
		banco.depositar(1, 100.0);
		assertEquals(banco.getMovimientos(), 1, 0.0);
		banco.extraer(1, 100.0);
		assertEquals(banco.getMovimientos(), 2, 0.0);
		banco.transferir(1, 2, 100.0);
		assertEquals(banco.getMovimientos(), 4, 0.0);
		

	}
}
