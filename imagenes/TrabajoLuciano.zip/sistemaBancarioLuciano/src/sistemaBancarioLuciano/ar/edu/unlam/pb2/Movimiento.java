package sistemaBancarioLuciano.ar.edu.unlam.pb2;

public class Movimiento {

	private Integer idCuenta;
	private tipoOperacion tipoOperacion;
	private Double monto;

	public Movimiento(Integer idCuenta, tipoOperacion tipoOperacion, Double monto) {
		this.idCuenta = idCuenta;
		this.tipoOperacion = tipoOperacion;
		this.monto = monto;
	}

	public Integer getIdCuenta() {
		return idCuenta;
	}

	public tipoOperacion getTipoOperacion() {
		return tipoOperacion;
	}

	public Double getMonto() {
		return monto;
	}

}
