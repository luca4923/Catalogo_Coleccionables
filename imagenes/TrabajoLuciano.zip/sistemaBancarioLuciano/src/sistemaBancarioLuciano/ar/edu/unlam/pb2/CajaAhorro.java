package sistemaBancarioLuciano.ar.edu.unlam.pb2;

public class CajaAhorro extends Cuenta {

	public CajaAhorro(Integer id, String titular, Double saldo) {
		super(id, saldo, titular);
	}

	@Override
	public Boolean depositar(Double monto) {
		if (monto > 0) {
			setSaldo(getSaldo() + monto);
			return true;
		}

		return false;
	}

	@Override
	public Boolean extraer(Double monto) {
		Double comision = 5.0;
		if (monto > 0) {
			setSaldo(getSaldo() - (monto + comision));
			return true;
		}

		return false;
	}


}
