package sistemaBancarioLuciano.ar.edu.unlam.pb2;

import java.util.ArrayList;
import java.util.HashSet;

public class Banco {

	private HashSet<Cuenta> cuentas;
	private ArrayList<Movimiento> movimientos;

	public Banco(String nombre) {
		this.cuentas = new HashSet<Cuenta>();
		this.movimientos = new ArrayList<Movimiento>();

	}

	public Boolean agregarCuenta(Cuenta cuenta) {
		if (cuenta == null) {
			return false;
		}
		return this.cuentas.add(cuenta);

	}

	public Cuenta buscarCuenta(Integer id) {
		for (Cuenta cuenta : cuentas) {
			if (cuenta.getId() == id)
				return cuenta;
		}
		return null;

	}

	public Boolean depositar(Integer id, Double monto) {
		Cuenta cuenta = buscarCuenta(id);

		if (cuenta != null) {
			movimientos.add(new Movimiento(id, tipoOperacion.DEPOSITO, monto));
			cuenta.depositar(monto);
			return true;
		}
		return false;
	}

	public Boolean extraer(Integer id, Double monto) {
		Cuenta cuenta = buscarCuenta(id);

		if (cuenta != null) {
			movimientos.add(new Movimiento(id, tipoOperacion.EXTRACCION, monto));
			cuenta.extraer(monto);
			return true;
		}
		return false;

	}

	public Boolean transferir(Integer idOrigen, Integer idDestino, Double monto) {
		Cuenta cuentaOrigen = buscarCuenta(idOrigen);
		Cuenta cuentaDestino = buscarCuenta(idDestino);
		if (monto >= 0 && (cuentaDestino != null && cuentaOrigen != null) && cuentaDestino.getId() != cuentaOrigen.getId()) {
			if (cuentaDestino.depositar(monto) && cuentaOrigen.extraer(monto)) {
				movimientos.add(new Movimiento(idDestino, tipoOperacion.TRANSFERENCIA_RECIBIDA, monto));
				movimientos.add(new Movimiento(idOrigen, tipoOperacion.TRANSFERENCIA_ENVIADA, monto));
				return true;
			}
		}

		return false;

	}

	public Integer getCuentas() {
		return cuentas.size();
	}

	public Integer getMovimientos() {
		return movimientos.size();
	}

}
