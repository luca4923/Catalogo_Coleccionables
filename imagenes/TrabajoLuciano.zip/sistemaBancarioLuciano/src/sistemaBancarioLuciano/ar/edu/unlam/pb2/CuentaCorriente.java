package sistemaBancarioLuciano.ar.edu.unlam.pb2;

public class CuentaCorriente extends Cuenta {

	private Double limiteDescubierto;

	public CuentaCorriente(Integer id, String titular, Double saldo, Double limiteDescubierto) {
		super(id, saldo, titular);
		this.limiteDescubierto = limiteDescubierto;

	}

	public Double getLimiteDescubierto() {
		return limiteDescubierto;
	}

	@Override
	public Boolean depositar(Double monto) {
		if (monto > 0) {
			setSaldo(getSaldo() + monto);
			return true;
		}
		return false;
	}

	@Override
	public Boolean extraer(Double monto) {
		if (monto <= 0 || getSaldo() - monto + getLimiteDescubierto() < 0) {
			return false;
		}
		setSaldo(getSaldo() - monto);
		return true;
	}

}
