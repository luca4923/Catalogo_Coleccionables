package sistemaBancarioLuciano.ar.edu.unlam.pb2;

public enum tipoOperacion {
	DEPOSITO, EXTRACCION, TRANSFERENCIA_ENVIADA, TRANSFERENCIA_RECIBIDA;
}
