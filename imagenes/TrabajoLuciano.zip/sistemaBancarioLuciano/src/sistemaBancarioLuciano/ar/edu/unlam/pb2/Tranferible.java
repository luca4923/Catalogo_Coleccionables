package sistemaBancarioLuciano.ar.edu.unlam.pb2;

public interface Tranferible {
	Boolean depositar(Double monto);
	Boolean extraer(Double monto);
	Double getSaldo();
}
