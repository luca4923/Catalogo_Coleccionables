package sistemaBancarioLuciano.ar.edu.unlam.pb2;

import java.util.Objects;

public abstract class Cuenta implements Tranferible {

	private Integer id;
	private Double saldo;
	private String titular;

	public Cuenta(Integer id, Double saldo, String titular) {
		this.id = id;
		this.saldo = saldo;
		this.titular = titular;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Double getSaldo() {
		return saldo;
	}

	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cuenta other = (Cuenta) obj;
		return Objects.equals(id, other.id);
	}

}
